<?php

//admin_acc/api.php
 
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin_acc\UserManagementController;
use App\Http\Controllers\ApiAuthController;
use App\Http\Controllers\ApiForgotPasswordController;
use App\Http\Controllers\admin_acc\DoctorController;
use App\Http\Controllers\admin_acc\AdminDashboardController;
use App\Http\Controllers\admin_acc\ApiProfileController;
use App\Http\Controllers\admin_acc\FeedbackController;
use App\Http\Controllers\admin_acc\VisitController;
use App\Http\Controllers\admin_acc\PatientListController;
use App\Http\Controllers\admin_acc\NotificationController;
use App\Http\Controllers\admin_acc\ComplaintController;
use App\Http\Controllers\Api\InquiryController;

Route::prefix('admin')->group(function () {

 
// ── User management ──
Route::get('/users',                    [UserManagementController::class, 'getUsers']);
Route::post('/users',                   [UserManagementController::class, 'store']);
Route::put('/users/{id}',               [UserManagementController::class, 'update']);
Route::patch('/users/{id}/toggle',      [UserManagementController::class, 'toggleStatus']);
Route::delete('/users/{id}',            [UserManagementController::class, 'destroy']);

// forgot pass in dart
Route::post('/forgot-password/send-otp',   [ApiForgotPasswordController::class, 'sendOtp']);
Route::post('/forgot-password/verify-otp', [ApiForgotPasswordController::class, 'verifyOtp']);
Route::post('/forgot-password/resend-otp', [ApiForgotPasswordController::class, 'resendOtp']);
Route::post('/forgot-password/reset',      [ApiForgotPasswordController::class, 'resetPassword']);

//doctors
Route::get('/doctors', [DoctorController::class, 'apiIndex']);
Route::post('/doctors', [DoctorController::class, 'store']);
Route::put('/doctors/{id}', [DoctorController::class, 'update']);
Route::patch('/doctors/{id}/toggle', [DoctorController::class, 'toggleStatus']);
Route::delete('/doctors/{id}', [DoctorController::class, 'destroy']);

Route::get('/dashboard-data', [Admindashboardcontroller::class, 'data']);

//mobile profile
Route::middleware('auth:sanctum')->get('/me', [ApiProfileController::class, 'show']);
Route::middleware('auth:sanctum')->post('/profile/photo', [ApiProfileController::class, 'updatePhoto']);

//feedback list
Route::get('/feedback', [FeedbackController::class, 'apiIndex']);
Route::get('/feedback/diagnose', [FeedbackController::class, 'diagnoseRootCauses']);

//schedule visit list
Route::get('/appointments', [VisitController::class, 'apiIndex']);

//Patient list

Route::get('/patients', [PatientListController::class, 'apiIndex']);
Route::post('/patients', [PatientListController::class, 'store']);
Route::put('/patients/{id}', [PatientListController::class, 'update']);
Route::get('/patients/service-types', [PatientListController::class, 'apiServiceTypes']);
Route::get('/patients/{id}/visits', [PatientListController::class, 'apiVisits']);
Route::patch('/visits/{id}/notes', [PatientListController::class, 'updateVisitNotes']);

//ccomplaints list
Route::get('/complaints', [ComplaintController::class, 'apiIndex']);

Route::get('/notifications', [NotificationController::class, 'apiIndex']);
Route::patch('/notifications/{id}/read', [NotificationController::class, 'markRead']);
Route::post('/notifications/mark-all-read', [NotificationController::class, 'markAllRead']);

// ── Chatbot Inquiries (patient messages the bot couldn't handle) ──
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/inquiries', [InquiryController::class, 'index']);
    Route::get('/inquiries/{inquiry}', [InquiryController::class, 'show']);
    Route::get('/inquiries/{inquiry}/messages', [InquiryController::class, 'messages']);
    Route::post('/inquiries/{inquiry}/messages', [InquiryController::class, 'sendMessage']);
    Route::post('/inquiries/{inquiry}/resolve', [InquiryController::class, 'resolve']);
});
});